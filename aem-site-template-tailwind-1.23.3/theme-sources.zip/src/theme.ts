// Stylesheets
import "./theme.css";
import "./resources/images/favicon.png";

// Component Javascript

// Wireframe Demo JavaScript
import "../demos/wireframe/theme";
